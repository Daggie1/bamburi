package com.muva.bamburi.utils;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

/**
 * Created by Njoro on 4/25/18.
 */
@GlideModule
public class MyGlideAppModule extends AppGlideModule {
}
