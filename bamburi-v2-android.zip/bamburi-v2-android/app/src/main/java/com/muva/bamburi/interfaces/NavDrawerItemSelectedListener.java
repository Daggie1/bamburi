package com.muva.bamburi.interfaces;

import android.view.View;

/**
 * Created by Njoro on 4/25/18.
 */
public interface NavDrawerItemSelectedListener {
    void onNavDrawerItemSelected(View view, int position);
}
