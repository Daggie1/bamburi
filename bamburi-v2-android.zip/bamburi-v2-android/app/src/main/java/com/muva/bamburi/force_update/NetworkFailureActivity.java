package com.muva.bamburi.force_update;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class NetworkFailureActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_network_failure);
    }
}
